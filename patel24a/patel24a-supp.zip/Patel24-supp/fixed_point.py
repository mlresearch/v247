import numpy as np 
from numpy.linalg import matrix_power, inv, norm
import matplotlib.pyplot as plt

# Data preparation
x_1 = np.array([5,5])
x_2 = np.array([15,5])
x_3 = np.array([15,10])
x_4 = np.array([10,20])
x_5 = np.array([5,15])

x_bar = (x_1 + x_2 + x_3 + x_4 + x_5)/5
x_star = np.array([11,12])

A_1 = np.diag([1,2])
A_2 = np.diag([1,1])
A_3 = np.diag([6,1])
A_4 = np.diag([4,1])
A_5 = np.diag([3,5])

I = np.eye(2)

x_fixed_dist = np.zeros((7,100))

for K in np.arange(100)+1:
    eta = 1/7
    C = (I - matrix_power(I-eta*A_1, K) + I - matrix_power(I-eta*A_2, K) + I - matrix_power(I-eta*A_3, K) + I - matrix_power(I-eta*A_4, K) + I - matrix_power(I-eta*A_5, K))/5
    x_fixed = np.dot(inv(C), (np.dot(I - matrix_power(I-eta*A_1, K), x_1) + np.dot(I - matrix_power(I-eta*A_2, K), x_2) + np.dot(I - matrix_power(I-eta*A_3, K), x_3) + np.dot(I - matrix_power(I-eta*A_4, K), x_4) + np.dot(I - matrix_power(I-eta*A_5, K), x_5))/5)
    x_fixed_dist[0][K-1] = norm(x_fixed-x_star)

eta_scales = [1/(7*(K**n)) for n in [0.5, 1, 1.5, 2, 2.5, 3]]
for j, eta_scale in enumerate(eta_scales, start=1):
    for K in np.arange(100)+1:
        eta = eta_scale if j != 2 else 1/(7*K)
        C = sum(I - matrix_power(I-eta*eval(f"A_{i}"), K) for i in range(1, 6))/5
        x_fixed = np.dot(inv(C), sum(np.dot(I - matrix_power(I-eta*eval(f"A_{i}"), K), eval(f"x_{i}")) for i in range(1, 6))/5)
        x_fixed_dist[j][K-1] = norm(x_fixed-x_star)

# Plotting with thicker lines for better visibility in smaller formats
plt.figure(figsize=(10, 6))
colors = plt.cm.tab10(np.linspace(0, 1, 10))
# Reverting labels back to original without indicating convergence to x_bar for the first two curves
labels = [r"$\eta=\frac{1}{7}$", r"$\eta=\frac{1}{7\sqrt{K}}$", r"$\eta=\frac{1}{7K}$", r"$\eta=\frac{1}{7K^{3/2}}$", r"$\eta=\frac{1}{7K^2}$", r"$\eta=\frac{1}{7K^{2.5}}$", r"$\eta=\frac{1}{7K^3}$"]

for i, color in zip(range(7), colors):
    # Increased line width for better visibility
    plt.plot(np.arange(3, 101), x_fixed_dist[i][2:], label=labels[i], color=color, marker='o', markersize=6, linestyle='-', linewidth=4, markevery=5)

plt.xlabel('Local steps $K$', fontsize=24)
plt.ylabel('$\log_{10}||x_{\infty}-x*||_2$', fontsize=24)
plt.yscale('log')
# Keeping the legend multi-column and positioned to avoid obscuring curves
plt.legend(fontsize=15, loc='lower right', ncol=4)
plt.grid(True, which='both', linestyle='--', linewidth=0.5)
plt.tight_layout()
plt.savefig("COLT_24.png", dpi=300)
